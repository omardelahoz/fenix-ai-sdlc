package main

import (
	"fmt"
)

func main() {
	fmt.Println("Starting F�nix Core...")
}

