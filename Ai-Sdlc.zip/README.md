# 🔥 Fénix AI SDLC

> **The AI-Native Engineering Operating System**

Fénix is not just another AI coding framework or agent orchestrator. It is a full-fledged **AI-Native Engineering Operating System** built around declarative specifications rather than imperative scripts. 

Instead of relying on prompt engineering or fragile ad-hoc instructions, products, workflows, and processors in Fénix are described using custom **Domain-Specific Languages (DSLs)**. These languages are compiled into a canonical engineering model, allowing the platform to manage the entire Software Development Life Cycle (SDLC) deterministically, where the orchestration of AI agents is just the final execution step.

---

## 🚀 The Fénix Language System

Fénix introduces three domain-specific languages that form the heart of the system:

- **FDL (Fénix Definition Language):** Describes **WHAT** the product is (Entities, UI, Architecture).
- **WDL (Workflow Definition Language):** Describes **HOW** engineering workflows execute (Pipelines, CI/CD).
- **PMF (Processor Manifest Format):** Describes **HOW** plugins and processors integrate into the platform.

These languages are processed by a custom-built, industrial-grade compiler pipeline that features a Lexer, Parser, AST, Binder, and Semantic Model. 

---

## ⚙️ The Compiler Pipeline

Fénix's biggest innovation is its execution pipeline. Instead of sending raw text to an LLM, Fénix compiles declarative DSLs into structured Intermediate Representations (IR):

```text
FDL / WDL / PMF
       │
       ▼
 Fénix Language System (Lexer, Parser, AST, Binder)
       │
       ▼
 Canonical Language IR
       │
       ▼
 Engineering IR Builder
       │
       ▼
   Fénix Runtime
       │
       ▼
   Execution (AI Agents / Adapters)
```

---

## 🏗 Planned Architecture

```text
                  Fenix AI SDLC

              CLI • IDE • Dashboard

                       │
                       ▼

            Fenix Language System
        (FDL • WDL • PMF Compiler)

                       │
                       ▼

              Canonical Language IR

                       │
                       ▼

              Engineering IR Builder

                       │
                       ▼

                 Fenix Runtime

        ┌────────────┼────────────┐
        │            │            │
 Product Memory  Validation   Report Engine
        │            │            │
        └────────────┼────────────┘
                     │
                     ▼
             Multi-Agent Orchestrator
                     │
                     ▼
          Claude • Codex • Gemini • ...
```

---

## 🧠 Product Memory (Knowledge Graph)

Product Memory in Fénix is not just a document database. It is a rich, structured **Knowledge Graph** containing:

- Specifications & Requirements
- Architecture & Decisions (ADRs)
- The compiled Semantic Model
- Generated Artifacts
- The Engineering IR
- Historical Versions

This completely eliminates context loss, allowing any AI model to seamlessly jump into a project months later and understand the exact state of the system.

---

## 🎯 The Real Differentiator

What makes Fénix fundamentally different from tools like Cursor, Claude Code, Aider, or OpenHands?

- **Custom Compiler:** A bespoke Language System built from scratch.
- **Three DSLs:** FDL, WDL, and PMF to model the entire SDLC.
- **Canonical IR & Engineering IR:** Structured representations instead of raw text prompts.
- **Declarative Architecture:** You declare the end-state, Fénix figures out the execution.
- **Decoupled Runtime:** The Language System is cleanly separated from the Multi-Agent Execution Runtime.
- **Advanced Product Memory:** True semantic understanding of the software product.
- **Model Agnostic:** Swap Claude, Gemini, or local LLMs seamlessly under the Fénix Runtime.

---

## 📁 Repository Structure

```text
fenix-ai-sdlc/

├── core/          # Core platform utilities
│   ├── language/  # The Fénix Language System (Lexer, Parser, AST, Binder)
│   ├── compiler/  # Semantic Analysis, Canonical IR, Engineering IR
│   ├── runtime/   # Execution Engine, Agent Orchestrator
│   ├── memory/    # Product Memory & Knowledge Graph
│   └── validation/# Quality and Standards Validation
├── adapters/      # Integrations with external AI models (Claude, Gemini, etc.)
├── templates/     # Project and code generation templates
├── definitions/   # Standard library of FDL/WDL/PMF definitions
├── docs/          # Specifications (Series 100, 200, 300) and architecture
└── tools/         # CLI, Dashboard, and internal tooling
```

---

## 🤝 Contributing

Fénix is currently in a heavy architectural design phase (refer to the `docs/spec/` directory). 
Contributions, discussions, architecture proposals, and feedback are welcome.

---

## 📄 License

License to be defined.
