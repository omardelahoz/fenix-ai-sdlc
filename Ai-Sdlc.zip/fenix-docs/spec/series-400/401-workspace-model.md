# SPEC-401: Workspace Model

## 1. Executive Summary
The Workspace Model is the structural representation of the user's codebase. It manages the physical layout (files, folders) and maps it to the logical layout (Projects, Modules, Dependencies). It is the absolute source of truth for file contents, versioning tokens, and project dependency graphs, acting as the foundation upon which the Compiler Host operates.

## 2. Structural Hierarchy
The model follows a strict, hierarchical containment graph:

```text
Workspace
 └── Project (e.g., Frontend, Backend, AgentDefinitions)
      ├── Dependency Graph (References to other projects)
      └── Document (Source code files: .fdl, .wdl, .pmf)
           ├── Version (SyntaxVersion)
           └── SourceText (Immutable string/buffer)
```

## 3. The Dependency Graph
Projects in Fénix rarely exist in isolation. The Workspace maintains a DAG (Directed Acyclic Graph) of Project Dependencies.
If `Project B` depends on `Project A`, and a user or agent modifies a file in `Project A`:
1. The Workspace increments `Project A`'s `SyntaxVersion` and (if needed) `SemanticVersion`.
2. The Workspace traverses the DAG and invalidates `Project B`'s active compilation snapshot.
3. Cross-Project Incrementality (SPEC-309) ensures `Project B` only recompiles the specific modules that consume the changed symbols in `Project A`, instead of rebuilding the entire project.

## 4. File Watchers and External Changes
Fénix does not assume the IDE is the only actor modifying files. AI Agents, code generators, or Git branch checkouts might change files on disk autonomously.
The Workspace Model integrates OS-level File Watchers (e.g., `fsnotify` or `inotify`).

When a change occurs externally:
1. The Watcher triggers a `FileChanged` event.
2. The Workspace swaps the `SourceText` buffer for that Document.
3. It increments the appropriate `VersionTokens`.
4. It notifies the Compiler Host to gracefully cancel obsolete tasks and schedule a new incremental background compilation.

## 5. The Workspace Interface
```go
type Workspace interface {
    // Topology
    Projects() []Project
    GetProject(id string) (Project, error)
    GetDocument(uri URI) (Document, error)
    GetDependencyGraph() DirectedGraph
    
    // Mutations (Returns a new immutable Workspace snapshot)
    UpdateDocument(uri URI, newText string) Workspace
    AddProject(config ProjectConfig) Workspace
    RemoveProject(id string) Workspace
}

type Project interface {
    ID() string
    Documents() []Document
    Dependencies() []Project
}

type Document interface {
    URI() URI
    Text() SourceText
    SyntaxVersion() int
}
```
