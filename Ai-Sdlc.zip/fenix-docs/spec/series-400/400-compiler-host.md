# SPEC-400: Compiler Host

## 1. Executive Summary
The Compiler Host is the daemon/process that wraps the Fénix Compilation Pipeline (Series 300) and exposes it to the outside world. Without the Host, the compiler is merely a static library; with the Host, it becomes an intelligent, reactive Engine. It handles scheduling, concurrency, caching, and lifecycle management for Language Services, AI Agents, and the CLI.

## 2. Concurrency Model: Immutable Shared Memory
Fénix avoids traditional Actor Models (message passing) for the Compiler Host. Serializing access to semantic data through a single message queue creates massive bottlenecks when hundreds of AI Agents and IDE features query the code concurrently.

Instead, the Host uses **Immutable Shared Memory with RWLocks**.
- The `Workspace` and `Compilation` snapshots are mathematically immutable (SPEC-309).
- Thousands of Goroutines (AI Agents, LSP Requests, CLI commands) can read the Semantic Model simultaneously by acquiring a simple `RLock()`.
- A write `Lock()` is only acquired for microseconds to swap the pointer of the old Compilation snapshot with a new one when a file changes.

## 3. Host Responsibilities
1. **Lifecycle Orchestration:** Coordinates `OpenDocument`, `CloseDocument`, and `DidChange` events from the IDE or external editors.
2. **Intelligent Scheduling:** Prioritizes tasks. For example, Autocomplete (which must answer in sub-milliseconds) is scheduled with higher priority than Full Semantic Analysis (which runs in the background).
3. **Fast Cancellation Propagation:** Every request accepts a `context.Context`. If the user types a new character in the IDE, the Host immediately calls `cancel()` on all ongoing background computations bound to the outdated snapshot, preventing CPU waste.
4. **Cache & Garbage Collection:** Manages the memory lifecycle of `Compilation` snapshots. Drops old snapshots to prevent OOM (Out Of Memory) errors, while strictly preserving the structural hash caches (SPEC-309).

## 4. The Compiler Host Interface
```go
type CompilerHost interface {
    // Lifecycle
    OpenWorkspace(uri URI) (*Workspace, error)
    ApplyEdit(edit WorkspaceEdit) error
    
    // Concurrency & Snapshots
    // Acquires an RLock and returns the latest immutable snapshot
    GetLatestCompilation(ctx context.Context, projectID string) (*Compilation, error)
    
    // Services
    GetLanguageServices() LanguageService
    
    // Event Subscriptions
    SubscribeToDiagnostics(callback func([]Diagnostic))
    SubscribeToWorkspaceChanges(callback func(WorkspaceEvent))
}
```
